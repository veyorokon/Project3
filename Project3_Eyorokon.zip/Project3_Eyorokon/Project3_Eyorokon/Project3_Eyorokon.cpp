// Project3_Eyorokon.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "AVLTree.h"
#include <iostream>
#include <string>
using namespace std;

int main()
{
	AVLTree a;
	cout << "Add 10 " + to_string(a.insert(10, 0)) << endl;
	cout << "Add 10 again " + to_string(a.insert(10, 0)) << endl;
	cout << "Add 5 " + to_string(a.insert(5, 0)) << endl;
	cout << "Add 15 " + to_string(a.insert(15, 0)) << endl;
	cout << "Add 25 " + to_string(a.insert(25, 0)) << endl;
	cout << "Add 35 " + to_string(a.insert(35, 0)) << endl;
	cout << "Add 45 " + to_string(a.insert(45, 0)) << endl;
	cout << "Add 9 " + to_string(a.insert(9, 0)) << endl;
	cout << "Add 7 " + to_string(a.insert(7, 0)) << endl;
	cout << "Add 8 " + to_string(a.insert(8, 0)) << endl;
	cout << "Add 4 " + to_string(a.insert(4, 0)) << endl;
	cout << "Add 3 " + to_string(a.insert(3, 0)) << endl;
	cout << "Add 2 " + to_string(a.insert(2, 0)) << endl;
	cout << "Add 1 " + to_string(a.insert(1, 0)) << endl;

	cout << "root key= " + to_string(a.root->key) << endl;
	cout << "depth of root left child "+ to_string(a.root->leftChild->leftDepth) << endl;
	//cout << "depth of root right child " + to_string(a.root->rightChild->rightChild->rightDepth) << endl;
	system("pause");
    return 0;
}

