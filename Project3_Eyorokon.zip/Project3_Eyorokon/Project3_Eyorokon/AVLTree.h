#pragma once

using namespace std;
class AVLTree
{
	class Node
	{
		/*Node class is the atomic piece of the tree that contains one key, 
		value pair. The Node also tracks left, right and parent Nodes. It also
		maintains the depth of both subtrees. */
	public:
		//left/right Depth, keeps track of respective depths.
		int key, value, leftDepth, rightDepth;
		//left/right Child and parentNode are pointers to respective children and parent Nodes.
		Node * leftChild, * rightChild, * parentNode;
		Node()
		{
			key = -1;
			value = -1;
			leftDepth = 0;
			rightDepth = 0;
		}
		/*Constructor specifying new key and value.*/
		Node(int newKey, int newVal)
		{
			key = newKey;
			value = newVal;
			leftDepth = 0;
			rightDepth = 0;
		}
		~Node()
		{
		}
		/*Returns the greatest depth between two nodes specified*/
		int Node::greatestDepth() {
			int lcDepth = 0, rcDepth = 0;
			if (leftChild) {
				lcDepth = (leftChild->leftDepth >= leftChild->rightDepth ?
					leftChild->leftDepth : leftChild->rightDepth);//Get greatest depth of left child
			}
			if (rightChild) {
				rcDepth = (rightChild->leftDepth >= rightChild->rightDepth ?
					rightChild->leftDepth : rightChild->rightDepth);//Get greatest depth of right child
			}
			return lcDepth >= rcDepth ? lcDepth : rcDepth;
		}

	};

public:
	Node * root;
	int size;

	AVLTree()
	{
		size = 0;
	}
	~AVLTree()
	{
	}

	bool AVLTree::insert(int key, int value) {
		// New Node containing new key/value pair.
		Node * newNode = new Node(key, value);
		if (!root) {
			root = new Node(key, value);
			return 1;
		}
		return insertHelper(newNode, root); //return success or fail
	}

	int AVLTree::insertHelper(Node * newNode, Node* subRoot) {
		
		if (newNode->key == subRoot->key) //Check for Duplicate
		{
			delete(newNode); // Remove it
			return 0;
		}
		if (newNode->key < subRoot->key) //Check if key is less than
		{
			if (!(subRoot->leftChild)) { //Check if leftChild is NULL 
				return addNode(newNode, subRoot, true); //Insert newNode
			}
			int depth = insertHelper(newNode, subRoot->leftChild); //If we successfully added
			if (depth) 
				subRoot->leftDepth = subRoot->greatestDepth() + 1; //Set depth to greatest + 1
			else return 0; //If node was duplicate, pass 0
		}
		if (newNode->key > subRoot->key) // Check if key is greater than
		{
			if (!(subRoot->rightChild)) { // Check if rightChild is NULL
				return addNode(newNode, subRoot, false); //Insert newNode
			}
			int depth = insertHelper(newNode, subRoot->rightChild); //Recurse
			if (depth)
				subRoot->rightDepth = subRoot->greatestDepth() + 1; //Set depth to greatest + 1
			else return 0; //If node was duplicate, pass 0
		}
		return 1;
	}

	/*Adds newNode as either left or right child of the parent*/
	int AVLTree::addNode(Node* newNode, Node* parent, bool isLeftChild) {
		if (isLeftChild) {
			parent->leftChild = newNode; // Set subroot's left child
			newNode->parentNode = parent; // Set newNode's parent
			parent->leftDepth++;
		}
		else {
			parent->rightChild = newNode; // Set subRoot's right child
			newNode->parentNode = parent; // Set newNode's parent
			parent->rightDepth++;
		}
		size++;
		return 1;
	}
};

